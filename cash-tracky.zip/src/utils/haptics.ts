/**
 * Advanced Haptic Feedback Engine using the HTML5 Vibration API.
 * Provides tactile mobile feedback for touches, transactions, toggles, and system states.
 */

let hapticsEnabled = true;

// Retrieve persisted preference if available
if (typeof window !== 'undefined') {
  try {
    const saved = localStorage.getItem('cashtracky_haptics_enabled');
    if (saved !== null) {
      hapticsEnabled = saved === 'true';
    }
  } catch {
    // Ignore localStorage errors
  }
}

export function setHapticsEnabled(enabled: boolean) {
  hapticsEnabled = enabled;
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('cashtracky_haptics_enabled', String(enabled));
    } catch {
      // Ignore
    }
  }
}

export function isHapticsEnabled(): boolean {
  return hapticsEnabled;
}

/**
 * Safely trigger vibration if supported and enabled
 */
function triggerVibration(pattern: number | number[]) {
  if (!hapticsEnabled) return;
  if (typeof window === 'undefined' || typeof navigator === 'undefined') return;

  try {
    if ('vibrate' in navigator && typeof navigator.vibrate === 'function') {
      navigator.vibrate(pattern);
    }
  } catch {
    // Vibration may be restricted on some platforms
  }
}

/**
 * Ultra-crisp 8ms haptic tick for list item selections, country picker, currency switch.
 */
export function hapticSelection() {
  triggerVibration(8);
}

/**
 * Crisp 12ms tap for standard buttons, tabs, keypad entries, chips.
 */
export function hapticLight() {
  triggerVibration(12);
}

/**
 * Solid 22ms bump for prominent actions, modal open/close, toggle switches.
 */
export function hapticMedium() {
  triggerVibration(22);
}

/**
 * Distinct double-pulse rhythmic signature for successful transaction submissions,
 * completed onboarding, and saved goals: [Pulse (30ms), Pause (45ms), Pulse (40ms)].
 */
export function hapticSuccess() {
  triggerVibration([30, 45, 40]);
}

/**
 * Warning vibration pattern for budget threshold limits or item deletions:
 * [18ms, 35ms, 18ms, 35ms, 28ms].
 */
export function hapticWarning() {
  triggerVibration([18, 35, 18, 35, 28]);
}

/**
 * Heavy double bump for delete or reset actions.
 */
export function hapticHeavy() {
  triggerVibration([25, 40, 45]);
}
