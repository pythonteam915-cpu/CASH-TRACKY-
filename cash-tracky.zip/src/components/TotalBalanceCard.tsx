import React from 'react';
import { Wallet, Sparkles, TrendingUp, TrendingDown } from 'lucide-react';
import { formatCurrency, getAppCurrency } from '../utils/formatters';

interface TotalBalanceCardProps {
  balance: number;
  totalIncome: number;
  totalExpenses: number;
  savingsRate: number;
}

export const TotalBalanceCard: React.FC<TotalBalanceCardProps> = ({
  balance,
  totalIncome,
  totalExpenses,
  savingsRate,
}) => {
  const { code, symbol } = getAppCurrency();
  const isPositive = balance >= 0;

  return (
    <div className="relative group w-full mb-3.5">
      {/* Ambient prism glow */}
      <div className="absolute -top-4 -left-4 w-32 h-32 bg-violet-400/20 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-blue-400/20 rounded-full blur-2xl pointer-events-none" />

      {/* Main Glass-Prism Total Balance Card */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 glass-prism-hero border border-violet-200/70 shadow-md">
        {/* Specular top border highlight */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/90 to-transparent" />

        {/* Card Header Info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-violet-600/10 border border-violet-600/20 flex items-center justify-center text-violet-700 shadow-inner">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold tracking-wide text-violet-800 uppercase">
                Total Balance
              </p>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <span>Net Cash Flow</span>
                <span className="text-slate-300">·</span>
                <span className={isPositive ? 'text-emerald-600 font-semibold' : 'text-rose-600 font-semibold'}>
                  {isPositive ? 'Safe to spend' : 'Cash deficit'}
                </span>
              </div>
            </div>
          </div>

          {/* Savings Badge */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-violet-100/90 border border-violet-200 text-[11px] font-bold text-violet-800 shadow-2xs">
            <Sparkles className="w-3 h-3 text-pink-500" />
            <span>{savingsRate}% Saved</span>
          </div>
        </div>

        {/* Big Balance Amount */}
        <div className="mt-4 mb-2">
          <div className="flex items-baseline gap-2">
            <span
              className={`text-3xl sm:text-4xl font-black tracking-tight tabular-nums ${
                isPositive ? 'text-slate-950' : 'text-rose-600'
              }`}
            >
              {formatCurrency(balance)}
            </span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {code}
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
            {isPositive ? (
              <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Positive liquid cash reserves</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-rose-600 font-medium">
                <TrendingDown className="w-3.5 h-3.5" />
                <span>Expenses exceed registered income</span>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
