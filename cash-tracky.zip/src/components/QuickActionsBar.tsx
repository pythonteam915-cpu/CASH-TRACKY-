import React from 'react';
import { Plus, Minus, Receipt, Target } from 'lucide-react';
import { TransactionType } from '../types/finance';

interface QuickActionsBarProps {
  onAddTransaction: (type: TransactionType) => void;
  onNavigateToExpenses: () => void;
  onOpenBudgetGoal: () => void;
}

export const QuickActionsBar: React.FC<QuickActionsBarProps> = ({
  onAddTransaction,
  onNavigateToExpenses,
  onOpenBudgetGoal,
}) => {
  return (
    <div className="w-full mb-3.5">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
          Quick Actions
        </h3>
        <span className="text-[11px] font-semibold text-violet-600">
          Instant Record
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {/* Add Expense Button */}
        <button
          type="button"
          onClick={() => onAddTransaction('expense')}
          className="group relative flex items-center justify-center gap-2 py-3 px-3.5 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200/90 text-slate-800 font-bold text-xs sm:text-sm transition-all duration-200 active:scale-[0.98] shadow-2xs hover:shadow-xs cursor-pointer"
        >
          <div className="w-6 h-6 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 group-hover:bg-rose-100 transition-colors shrink-0">
            <Minus className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <span className="tracking-tight">Add Expense</span>
        </button>

        {/* Add Income Button */}
        <button
          type="button"
          onClick={() => onAddTransaction('income')}
          className="group relative flex items-center justify-center gap-2 py-3 px-3.5 rounded-2xl bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white font-bold text-xs sm:text-sm transition-all duration-200 active:scale-[0.98] shadow-md shadow-violet-500/20 border border-white/20 cursor-pointer"
        >
          <div className="w-6 h-6 rounded-lg bg-white/20 border border-white/30 flex items-center justify-center text-white group-hover:bg-white/30 transition-colors shrink-0">
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          </div>
          <span className="tracking-tight">Add Income</span>
        </button>
      </div>

      {/* Secondary Quick Access Pills */}
      <div className="grid grid-cols-2 gap-2 mt-2">
        <button
          type="button"
          onClick={onNavigateToExpenses}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-100/90 hover:bg-slate-200/70 border border-slate-200/70 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
        >
          <Receipt className="w-3.5 h-3.5 text-slate-500" />
          <span>View All Records</span>
        </button>

        <button
          type="button"
          onClick={onOpenBudgetGoal}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-100/90 hover:bg-slate-200/70 border border-slate-200/70 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
        >
          <Target className="w-3.5 h-3.5 text-violet-600" />
          <span>Adjust Budget</span>
        </button>
      </div>
    </div>
  );
};
