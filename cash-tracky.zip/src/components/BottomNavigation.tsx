import React from 'react';
import { motion } from 'motion/react';
import { Home, Receipt, Plus, PieChart, User } from 'lucide-react';
import { playTabSwitchSound, playAddButtonSound } from '../utils/soundEffects';
import { hapticLight, hapticMedium } from '../utils/haptics';

export type NavTab = 'home' | 'expenses' | 'add' | 'analytics' | 'profile';

interface BottomNavigationProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

interface NavItemConfig {
  id: NavTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const standardTabs: NavItemConfig[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'expenses', label: 'Expenses', icon: Receipt },
  // 'add' is center
  { id: 'analytics', label: 'Analytics', icon: PieChart },
  { id: 'profile', label: 'Profile', icon: User },
];

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onTabChange,
}) => {
  // Smooth ease-out transition config (250–320ms)
  const easeOutTransition = {
    duration: 0.28,
    ease: [0.16, 1, 0.3, 1] as const,
  };

  const handleTabClick = (tabId: NavTab) => {
    hapticLight();
    playTabSwitchSound();
    onTabChange(tabId);
  };

  const handleAddClick = () => {
    hapticMedium();
    playAddButtonSound();
    onTabChange('add');
  };

  const renderStandardTab = (tab: NavItemConfig) => {
    const isActive = activeTab === tab.id;
    const Icon = tab.icon;

    return (
      <button
        key={tab.id}
        type="button"
        onClick={() => handleTabClick(tab.id)}
        className="relative flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-2xl cursor-pointer min-h-[52px] select-none transition-colors"
      >
        {/* Active Icon Container with smooth scale & glass-prism glow */}
        <div className="relative flex items-center justify-center">
          {/* Subtle Glass-Prism Glow for Active Tab */}
          {isActive && (
            <motion.div
              layoutId="prism-glow"
              className="absolute -inset-2 bg-gradient-to-tr from-violet-500/25 via-blue-500/20 to-pink-500/20 rounded-full blur-xs pointer-events-none"
              transition={easeOutTransition}
            />
          )}

          {/* Tab Icon with smooth micro-scale motion */}
          <motion.div
            animate={{
              scale: isActive ? 1.08 : 1,
              y: isActive ? -1 : 0,
            }}
            transition={easeOutTransition}
            className={`relative p-1.5 rounded-xl transition-colors duration-200 ${
              isActive
                ? 'text-violet-600 bg-violet-50/90 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <Icon
              className={`w-5 h-5 transition-transform duration-200 ${
                isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'
              }`}
            />
          </motion.div>
        </div>

        {/* Tab Label with scale & font-weight transition */}
        <motion.span
          animate={{
            scale: isActive ? 1.02 : 0.98,
            color: isActive ? '#7c3aed' : '#64748b',
          }}
          transition={easeOutTransition}
          className={`text-[10px] sm:text-[11px] font-bold mt-0.5 tracking-tight ${
            isActive ? 'font-extrabold text-violet-700' : 'text-slate-600'
          }`}
        >
          {tab.label}
        </motion.span>
      </button>
    );
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center pointer-events-none px-3 pb-3 sm:pb-5">
      {/* Outer Floating Island Bar with Glass-Prism specular border */}
      <nav
        role="navigation"
        aria-label="Main Navigation"
        className="pointer-events-auto relative w-full max-w-[420px] rounded-[30px] p-2 glass-prism-nav border border-white/60 shadow-xl shadow-slate-900/10 transition-all duration-300"
      >
        {/* Specular Highlight along top edge */}
        <div className="absolute top-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-white/80 to-transparent pointer-events-none" />

        {/* Navigation Items Flexbox */}
        <div className="relative flex items-center justify-between gap-1">
          {/* Left standard tabs: Home & Expenses */}
          {renderStandardTab(standardTabs[0])}
          {renderStandardTab(standardTabs[1])}

          {/* CENTER ELEVATED '+' ADD BUTTON */}
          <div className="relative -top-5 px-1 flex flex-col items-center">
            {/* Pulsing ambient prism glow behind center button */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-violet-600 via-indigo-500 to-blue-500 rounded-full blur-md opacity-70 animate-pulse pointer-events-none" />

            <motion.button
              type="button"
              onClick={handleAddClick}
              whileTap={{ scale: 0.92 }}
              whileHover={{ scale: 1.05 }}
              transition={{ type: 'spring', stiffness: 450, damping: 25 }}
              aria-label="Add transaction"
              className="relative w-14 h-14 rounded-full flex items-center justify-center cursor-pointer shadow-lg shadow-violet-600/35 border-2 border-white/90 bg-gradient-to-tr from-violet-600 via-indigo-600 to-blue-500 text-white overflow-hidden group select-none"
            >
              {/* Internal Glass Sheen Reflection */}
              <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-black/15 pointer-events-none" />
              <div className="absolute -top-6 -left-6 w-12 h-12 bg-white/35 rounded-full blur-xs pointer-events-none" />

              {/* Plus Icon with gentle rotation micro-interaction on hover */}
              <Plus
                className={`w-7 h-7 stroke-[2.8] transition-transform duration-300 transform group-hover:rotate-90 ${
                  activeTab === 'add' ? 'rotate-45' : ''
                }`}
              />
            </motion.button>

            {/* Label below '+' Button for complete 5-tab clarity */}
            <span
              className={`text-[9px] sm:text-[10px] font-extrabold uppercase tracking-wider mt-1 transition-colors select-none ${
                activeTab === 'add' ? 'text-violet-700 font-black' : 'text-slate-500'
              }`}
            >
              Add
            </span>
          </div>

          {/* Right standard tabs: Analytics & Profile */}
          {renderStandardTab(standardTabs[2])}
          {renderStandardTab(standardTabs[3])}
        </div>
      </nav>
    </div>
  );
};
