import React from 'react';
import { ArrowDownLeft, ArrowUpRight, PiggyBank } from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface IncomeExpensesSavingsCardProps {
  totalIncome: number;
  totalExpenses: number;
  netSavings: number;
  savingsRate: number;
  incomeCount: number;
  expenseCount: number;
}

export const IncomeExpensesSavingsCard: React.FC<IncomeExpensesSavingsCardProps> = ({
  totalIncome,
  totalExpenses,
  netSavings,
  savingsRate,
  incomeCount,
  expenseCount,
}) => {
  return (
    <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-3.5">
      {/* 1. Total Income */}
      <div className="relative group overflow-hidden rounded-2xl sm:rounded-3xl p-3 sm:p-4 glass-card border border-emerald-200/70 shadow-2xs hover:border-emerald-300 transition-all">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Income
          </span>
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg sm:rounded-xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-700 shadow-2xs shrink-0">
            <ArrowDownLeft className="w-3 sm:w-3.5 h-3 sm:h-3.5 stroke-[2.5]" />
          </div>
        </div>

        <div className="space-y-0.5">
          <p className="text-sm sm:text-lg font-black tracking-tight text-slate-900 tabular-nums truncate">
            {formatCurrency(totalIncome)}
          </p>
          <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-slate-500 truncate">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>{incomeCount} {incomeCount === 1 ? 'entry' : 'entries'}</span>
          </div>
        </div>
      </div>

      {/* 2. Total Expenses */}
      <div className="relative group overflow-hidden rounded-2xl sm:rounded-3xl p-3 sm:p-4 glass-card border border-rose-200/70 shadow-2xs hover:border-rose-300 transition-all">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Expenses
          </span>
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg sm:rounded-xl bg-rose-100 border border-rose-200 flex items-center justify-center text-rose-700 shadow-2xs shrink-0">
            <ArrowUpRight className="w-3 sm:w-3.5 h-3 sm:h-3.5 stroke-[2.5]" />
          </div>
        </div>

        <div className="space-y-0.5">
          <p className="text-sm sm:text-lg font-black tracking-tight text-slate-900 tabular-nums truncate">
            {formatCurrency(totalExpenses)}
          </p>
          <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-slate-500 truncate">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            <span>{expenseCount} {expenseCount === 1 ? 'entry' : 'entries'}</span>
          </div>
        </div>
      </div>

      {/* 3. Net Savings */}
      <div className="relative group overflow-hidden rounded-2xl sm:rounded-3xl p-3 sm:p-4 glass-card border border-violet-200/70 shadow-2xs hover:border-violet-300 transition-all">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider text-slate-500">
            Savings
          </span>
          <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg sm:rounded-xl bg-violet-100 border border-violet-200 flex items-center justify-center text-violet-700 shadow-2xs shrink-0">
            <PiggyBank className="w-3 sm:w-3.5 h-3 sm:h-3.5 stroke-[2.2]" />
          </div>
        </div>

        <div className="space-y-0.5">
          <p className="text-sm sm:text-lg font-black tracking-tight text-slate-900 tabular-nums truncate">
            {formatCurrency(netSavings)}
          </p>
          <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-slate-500 truncate">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-violet-500"></span>
            <span>{savingsRate}% rate</span>
          </div>
        </div>
      </div>
    </div>
  );
};
