export const EXPENSE_CATEGORIES: { name: string; icon: string; color: string }[] = [
  { name: 'Housing', icon: 'Home', color: 'from-violet-500 to-indigo-600' },
  { name: 'Groceries', icon: 'ShoppingCart', color: 'from-emerald-500 to-teal-600' },
  { name: 'Dining & Drinks', icon: 'Utensils', color: 'from-amber-500 to-orange-600' },
  { name: 'Transport', icon: 'Car', color: 'from-sky-500 to-blue-600' },
  { name: 'Entertainment', icon: 'Film', color: 'from-pink-500 to-rose-600' },
  { name: 'Shopping', icon: 'ShoppingBag', color: 'from-fuchsia-500 to-purple-600' },
  { name: 'Health & Fitness', icon: 'HeartPulse', color: 'from-rose-500 to-pink-600' },
  { name: 'Subscriptions', icon: 'CreditCard', color: 'from-blue-500 to-indigo-600' },
  { name: 'Utilities', icon: 'Zap', color: 'from-yellow-500 to-amber-600' },
  { name: 'Other Expense', icon: 'MoreHorizontal', color: 'from-slate-500 to-slate-700' },
];

export const INCOME_CATEGORIES: { name: string; icon: string; color: string }[] = [
  { name: 'Salary', icon: 'Briefcase', color: 'from-blue-500 to-indigo-600' },
  { name: 'Freelance', icon: 'Laptop', color: 'from-violet-500 to-purple-600' },
  { name: 'Investments', icon: 'TrendingUp', color: 'from-emerald-500 to-teal-600' },
  { name: 'Bonus', icon: 'Sparkles', color: 'from-amber-500 to-yellow-500' },
  { name: 'Gifts & Cash', icon: 'Gift', color: 'from-pink-500 to-rose-500' },
  { name: 'Other Income', icon: 'PlusCircle', color: 'from-cyan-500 to-blue-500' },
];
